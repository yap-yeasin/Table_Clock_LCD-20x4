var searchData=
[
  ['pinmode',['pinMode',['../class_i2_c_i_o.html#a53b94274eb6bb68564cf5243323db887',1,'I2CIO']]],
  ['portmode',['portMode',['../class_i2_c_i_o.html#a0341888753bc54c4384f5593a870fb34',1,'I2CIO']]]
];
